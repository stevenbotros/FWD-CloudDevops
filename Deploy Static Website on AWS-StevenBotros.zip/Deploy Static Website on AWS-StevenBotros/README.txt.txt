Deploy Static Website on AWS
============================

LINKS:
======

Bucket website endpoint
http://fwdproject1bucket.s3-website-us-east-1.amazonaws.com

Cloud Front Domain Name
d32ep6je1tonjo.cloudfront.net	

S3 ObjectURL
Project one (index.html)
http://fwdproject1bucket.s3.amazonaws.com/index.html

Project two (stevenindex.html)
http://fwdproject1bucket.s3.amazonaws.com/stevenindex.html



HINTS:
======

- Please follow order of screenshots attached, each shows how project should meet all of the specifications in the Project Rubric respectively.

- Four screenshots show issue faced related to file uploading failure (buysellads.svg) and how reached the solution.

- 2 projects are uploaded:
* First one: using the normal index.html file downloaded from the classroom site (all the screenshots have prefix .1 after the specification number).
* Second one: using a customized index file named stevenindex.html; using a new company name and different background (all the screenshots have prefix .2 after the specification number).

